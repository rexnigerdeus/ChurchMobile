// src/screens/HomeScreen.tsx
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, FlatList, ActivityIndicator, Alert } from 'react-native';
import { supabase } from '../lib/supabase';
import ProfileScreen from './ProfileScreen';

type Tab = 'FEED' | 'DEPTS' | 'PROFILE';

export default function HomeScreen({ onNavigateToDeptLeader, onNavigateToAppointment, onNavigateToPrayer, onNavigateToPastor, onNavigateToSecretariat, onNavigateToFinance }: any) {
  const [activeTab, setActiveTab] = useState<Tab>('FEED');
  const [userName, setUserName] = useState('Fidèle');
  const [myRole, setMyRole] = useState('MEMBER');

  useEffect(() => {
    async function initUser() {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data: roleData } = await supabase.from('user_roles').select('role').eq('user_id', user?.id).single();
      if (roleData) setMyRole(roleData.role);

      let fetchedName = '';
      const { data: crm } = await supabase.from('church_members').select('full_name').eq('user_id', user?.id).single();
      
      if (crm?.full_name) {
        fetchedName = crm.full_name;
      } else {
        const { data: authProfile } = await supabase.from('user_profiles').select('full_name').eq('id', user?.id).single();
        if (authProfile) fetchedName = authProfile.full_name;
      }

      if (fetchedName) {
        const nameParts = fetchedName.split(' ');
        if (['Mme', 'M.', 'Mr', 'Mme.'].includes(nameParts[0]) && nameParts.length > 1) {
          setUserName(nameParts[1]);
        } else {
          setUserName(nameParts[0]);
        }
      }
    }
    initUser();
  }, []);

  // --- LE NOUVEAU FEED CONNECTÉ À LA BASE DE DONNÉES ---
  const FeedView = () => {
    const [loadingFeed, setLoadingFeed] = useState(true);
    const [announcements, setAnnouncements] = useState<any[]>([]);
    const [programs, setPrograms] = useState<any[]>([]);

    useEffect(() => {
      async function loadFeed() {
        const { data: { user } } = await supabase.auth.getUser();
        
        const { data: role } = await supabase.from('user_roles').select('entity_id').eq('user_id', user?.id).single();
        const { data: crm } = await supabase.from('church_members').select('church_id').eq('user_id', user?.id).single();
        const churchId = role?.entity_id || crm?.church_id;

        if (churchId) {
          // Charger les 3 dernières annonces
          const { data: ann } = await supabase.from('church_announcements').select('*').eq('church_id', churchId).order('created_at', { ascending: false }).limit(3);
          setAnnouncements(ann || []);

          // Charger les prochains programmes
          const { data: prog } = await supabase.from('church_programs').select('*').eq('church_id', churchId).gte('start_at', new Date().toISOString()).order('start_at', { ascending: true }).limit(3);
          setPrograms(prog || []);
        }
        setLoadingFeed(false);
      }
      loadFeed();
    }, []);

    const formatDate = (dateString: string) => {
      const options: Intl.DateTimeFormatOptions = { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' };
      return new Date(dateString).toLocaleDateString('fr-FR', options);
    };

    return (
      <ScrollView style={styles.scrollArea} showsVerticalScrollIndicator={false}>
        <Text style={styles.welcomeText}>Bonjour {userName} ! 👋</Text>
        
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickBtn} onPress={onNavigateToAppointment}>
            <Text style={styles.quickIcon}>📅</Text>
            <Text style={styles.quickLabel}>Prendre RDV</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickBtn} onPress={onNavigateToPrayer}>
            <Text style={styles.quickIcon}>🙏</Text>
            <Text style={styles.quickLabel}>Sujet de Prière</Text>
          </TouchableOpacity>
        </View>

        {loadingFeed ? (
           <ActivityIndicator size="small" color="#0f172a" style={{ marginVertical: 20 }} />
        ) : (
          <>
            <Text style={styles.sectionTitle}>Actualités de l'Église</Text>
            {announcements.length === 0 ? (
              <Text style={styles.emptyText}>Aucune annonce pour le moment.</Text>
            ) : (
              announcements.map(ann => (
                <View key={ann.id} style={styles.announcementCard}>
                  {ann.is_pinned && <Text style={styles.pinnedBadge}>📌 Épinglé</Text>}
                  <Text style={styles.announcementTitle}>{ann.title}</Text>
                  <Text style={styles.announcementBody} numberOfLines={3}>{ann.body}</Text>
                  <Text style={styles.dateText}>{new Date(ann.created_at).toLocaleDateString('fr-FR')}</Text>
                </View>
              ))
            )}

            <Text style={styles.sectionTitle}>Planning des réunions</Text>
            {programs.length === 0 ? (
              <Text style={styles.emptyText}>Aucun programme à venir.</Text>
            ) : (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingBottom: 10 }}>
                {programs.map(prog => (
                  <View key={prog.id} style={styles.programCard}>
                    <Text style={styles.programCategory}>{prog.category || 'Événement'}</Text>
                    <Text style={styles.programTitle} numberOfLines={1}>{prog.title}</Text>
                    <Text style={styles.programTime}>⏱ {formatDate(prog.start_at)}</Text>
                    <Text style={styles.programLocation}>📍 {prog.location}</Text>
                  </View>
                ))}
              </ScrollView>
            )}
          </>
        )}

        {/* BOUTONS ADMIN */}
        <View style={{ marginTop: 20, paddingBottom: 40 }}>
          {myRole === 'CHURCH_LEADER' && (
            <TouchableOpacity style={[styles.adminBtn, { backgroundColor: '#3b82f6' }]} onPress={onNavigateToPastor}>
              <Text style={styles.adminBtnText}>👔 Espace Pastoral</Text>
            </TouchableOpacity>
          )}
          {myRole === 'SECRETARY' && (
            <TouchableOpacity style={[styles.adminBtn, { backgroundColor: '#8b5cf6' }]} onPress={onNavigateToSecretariat}>
              <Text style={styles.adminBtnText}>🗂️ Espace Secrétariat</Text>
            </TouchableOpacity>
          )}
          {/* NOUVEAU : Bouton Finances */}
          {myRole === 'FINANCE_MANAGER' && (
            <TouchableOpacity style={[styles.adminBtn, { backgroundColor: '#10b981' }]} onPress={onNavigateToFinance}>
              <Text style={styles.adminBtnText}>💰 Espace Finances</Text>
            </TouchableOpacity>
          )}
          {/* NOUVEAU : Bouton Responsable Département */}
          {myRole === 'DEPARTMENT_LEADER' && (
            <TouchableOpacity style={[styles.adminBtn, { backgroundColor: '#f59e0b' }]} onPress={onNavigateToDeptLeader}>
              <Text style={styles.adminBtnText}>👥 Gestion Département</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    );
  };

  const DepartmentsView = () => {
    const [loading, setLoading] = useState(true);
    const [departments, setDepartments] = useState<any[]>([]);
    const [myRequests, setMyRequests] = useState<any[]>([]);

    useEffect(() => { loadDepts(); }, []);

    async function loadDepts() {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data: role } = await supabase.from('user_roles').select('entity_id').eq('user_id', user?.id).single();
      const { data: crm } = await supabase.from('church_members').select('church_id').eq('user_id', user?.id).single();
      
      const churchId = role?.entity_id || crm?.church_id;

      if (churchId) {
        const { data: church } = await supabase.from('churches').select('community_id').eq('id', churchId).single();
        
        let query = supabase.from('church_departments').select('*');
        if (church?.community_id) {
          query = query.or(`church_id.eq.${churchId},community_id.eq.${church.community_id}`);
        } else {
          query = query.eq('church_id', churchId);
        }
          
        const { data: depts } = await query;
        setDepartments(depts || []);

        const { data: reqs } = await supabase.from('department_members').select('*').eq('user_id', user?.id);
        setMyRequests(reqs || []);
      }
      setLoading(false);
    }

    async function handleJoin(deptId: string, deptName: string) {
      Alert.alert('Rejoindre', `Envoyer une demande pour : ${deptName} ?`, [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Confirmer', onPress: async () => {
            const { data: { user } } = await supabase.auth.getUser();
            const { error } = await supabase.from('department_members').insert({ department_id: deptId, user_id: user?.id, status: 'PENDING' });
            if (!error) { Alert.alert('Succès', 'Votre demande a été envoyée.'); loadDepts(); }
        }}
      ]);
    }

    if (loading) return <ActivityIndicator style={{marginTop: 50}} color="#0f172a" />;

    return (
      <View style={{ flex: 1 }}>
        <Text style={[styles.sectionTitle, { marginLeft: 20, marginTop: 20 }]}>Départements</Text>
        
        <FlatList
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
          data={departments}
          keyExtractor={(item) => item.id}
          ListEmptyComponent={<Text style={styles.emptyText}>Aucun département hérité ou créé.</Text>}
          renderItem={({ item }) => {
            const request = myRequests.find(r => r.department_id === item.id);
            return (
              <View style={styles.deptCard}>
                <View style={{ flex: 1, paddingRight: 10 }}>
                  <Text style={styles.deptName}>{item.name}</Text>
                  <Text style={styles.deptDesc}>{item.description || 'Département de l\'église'}</Text>
                </View>
                {!request ? (
                  <TouchableOpacity style={styles.joinBtn} onPress={() => handleJoin(item.id, item.name)}>
                    <Text style={styles.joinBtnText}>+ Rejoindre</Text>
                  </TouchableOpacity>
                ) : request.status === 'PENDING' ? (
                  <Text style={styles.statusPending}>⏳ En attente</Text>
                ) : request.status === 'APPROVED' ? (
                  <Text style={styles.statusApproved}>✅ Membre</Text>
                ) : (
                  <Text style={styles.statusRejected}>❌ Refusé</Text>
                )}
              </View>
            );
          }}
        />
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.topHeader}>
        <Text style={styles.headerTitle}>Revival Culture</Text>
      </View>

      <View style={{ flex: 1 }}>
        {activeTab === 'FEED' && <FeedView />}
        {activeTab === 'DEPTS' && <DepartmentsView />}
        {activeTab === 'PROFILE' && <ProfileScreen />}
      </View>

      <View style={styles.bottomNav}>
        <TouchableOpacity style={styles.navItem} onPress={() => setActiveTab('FEED')}>
          <Text style={[styles.navIcon, activeTab === 'FEED' && styles.navIconActive]}>🏠</Text>
          <Text style={[styles.navText, activeTab === 'FEED' && styles.navTextActive]}>Accueil</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setActiveTab('DEPTS')}>
          <Text style={[styles.navIcon, activeTab === 'DEPTS' && styles.navIconActive]}>👥</Text>
          <Text style={[styles.navText, activeTab === 'DEPTS' && styles.navTextActive]}>Départements</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setActiveTab('PROFILE')}>
          <Text style={[styles.navIcon, activeTab === 'PROFILE' && styles.navIconActive]}>👤</Text>
          <Text style={[styles.navText, activeTab === 'PROFILE' && styles.navTextActive]}>Profil</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  topHeader: { paddingTop: 50, paddingBottom: 15, paddingHorizontal: 20, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#e2e8f0' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#0f172a' },
  scrollArea: { flex: 1, padding: 20 },
  welcomeText: { fontSize: 24, fontWeight: 'bold', color: '#0f172a', marginBottom: 20 },
  quickActions: { flexDirection: 'row', gap: 15, marginBottom: 30 },
  quickBtn: { flex: 1, backgroundColor: '#fff', padding: 15, borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: '#e2e8f0' },
  quickIcon: { fontSize: 24, marginBottom: 5 },
  quickLabel: { fontSize: 13, fontWeight: '600', color: '#334155' },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: '#0f172a', marginTop: 10, marginBottom: 10 },
  emptyText: { fontStyle: 'italic', color: '#94a3b8', marginBottom: 20 },
  
  // Nouveaux styles Feed
  announcementCard: { backgroundColor: '#fff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  pinnedBadge: { alignSelf: 'flex-start', backgroundColor: '#fee2e2', color: '#ef4444', fontSize: 10, fontWeight: 'bold', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, marginBottom: 8 },
  announcementTitle: { fontSize: 15, fontWeight: 'bold', color: '#0f172a', marginBottom: 4 },
  announcementBody: { fontSize: 13, color: '#475569', lineHeight: 20 },
  dateText: { fontSize: 10, color: '#94a3b8', marginTop: 8, textAlign: 'right' },
  
  programCard: { backgroundColor: '#0f172a', padding: 16, borderRadius: 16, width: 220, marginRight: 15 },
  programCategory: { color: '#38bdf8', fontSize: 10, fontWeight: 'bold', textTransform: 'uppercase', marginBottom: 4 },
  programTitle: { color: '#fff', fontSize: 16, fontWeight: 'bold', marginBottom: 10 },
  programTime: { color: '#cbd5e1', fontSize: 12, marginBottom: 4 },
  programLocation: { color: '#94a3b8', fontSize: 11 },

  adminBtn: { padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 10 },
  adminBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 15 },
  deptCard: { backgroundColor: '#fff', padding: 15, borderRadius: 16, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  deptName: { fontSize: 16, fontWeight: 'bold', color: '#0f172a' },
  deptDesc: { fontSize: 12, color: '#64748b', marginTop: 2 },
  joinBtn: { backgroundColor: '#0f172a', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8 },
  joinBtnText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  statusPending: { fontSize: 12, color: '#f59e0b', fontWeight: 'bold' },
  statusApproved: { fontSize: 12, color: '#10b981', fontWeight: 'bold' },
  statusRejected: { fontSize: 12, color: '#ef4444', fontWeight: 'bold' },
  bottomNav: { flexDirection: 'row', backgroundColor: '#fff', paddingBottom: 25, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#e2e8f0' },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  navIcon: { fontSize: 20, opacity: 0.5 },
  navIconActive: { opacity: 1 },
  navText: { fontSize: 10, color: '#64748b', marginTop: 4, fontWeight: '500' },
  navTextActive: { color: '#0f172a', fontWeight: 'bold' }
});