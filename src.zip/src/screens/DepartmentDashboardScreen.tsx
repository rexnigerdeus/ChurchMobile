// src/screens/DepartmentDashboardScreen.tsx
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, ActivityIndicator, Alert } from 'react-native';
import { supabase } from '../lib/supabase';

type Tab = 'PENDING' | 'MEMBERS';

export default function DepartmentDashboardScreen({ onBack }: { onBack: () => void }) {
  const [activeTab, setActiveTab] = useState<Tab>('PENDING');
  const [loading, setLoading] = useState(true);
  const [deptInfo, setDeptInfo] = useState<any>(null);
  const [pendingRequests, setPendingRequests] = useState<any[]>([]);
  const [activeMembers, setActiveMembers] = useState<any[]>([]);

  useEffect(() => {
    loadDashboard();
  }, [activeTab]);

  async function loadDashboard() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    
    // 1. Trouver le département que l'utilisateur dirige
    const { data: roleData } = await supabase
      .from('user_roles')
      .select('department_id, church_departments(name)')
      .eq('user_id', user?.id)
      .eq('role', 'DEPARTMENT_LEADER')
      .single();

    if (roleData?.department_id) {
      setDeptInfo(roleData.church_departments);
      
      // 2. Charger les membres selon l'onglet
      if (activeTab === 'PENDING') {
        const { data } = await supabase
          .from('department_members')
          .select('*, member:user_profiles!department_members_user_id_fkey(full_name)')
          .eq('department_id', roleData.department_id)
          .eq('status', 'PENDING');
        setPendingRequests(data || []);
      } else {
        const { data } = await supabase
          .from('department_members')
          .select('*, member:user_profiles!department_members_user_id_fkey(full_name)')
          .eq('department_id', roleData.department_id)
          .eq('status', 'APPROVED');
        setActiveMembers(data || []);
      }
    }
    setLoading(false);
  }

  async function updateStatus(requestId: string, newStatus: 'APPROVED' | 'REJECTED') {
    const { error } = await supabase
      .from('department_members')
      .update({ status: newStatus })
      .eq('id', requestId);
    
    if (error) Alert.alert('Erreur', error.message);
    else loadDashboard();
  }

  return (
    <View style={styles.container}>
      {/* HEADER */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}><Text style={styles.backBtn}>⬅ Accueil</Text></TouchableOpacity>
        <Text style={styles.headerTitle}>Mon Département</Text>
        <View style={{ width: 50 }} />
      </View>

      <Text style={styles.deptTitle}>{deptInfo?.name || 'Département'}</Text>

      {/* TABS */}
      <View style={styles.tabContainer}>
        <TouchableOpacity style={[styles.tab, activeTab === 'PENDING' && styles.tabActive]} onPress={() => setActiveTab('PENDING')}>
          <Text style={[styles.tabText, activeTab === 'PENDING' && styles.tabTextActive]}>Demandes ({pendingRequests.length})</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab === 'MEMBERS' && styles.tabActive]} onPress={() => setActiveTab('MEMBERS')}>
          <Text style={[styles.tabText, activeTab === 'MEMBERS' && styles.tabTextActive]}>Membres</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#f59e0b" style={{ marginTop: 50 }} />
      ) : (
        <View style={{ flex: 1 }}>
          {activeTab === 'PENDING' ? (
            <FlatList
              data={pendingRequests}
              keyExtractor={(item) => item.id}
              ListEmptyComponent={<Text style={styles.emptyText}>Aucune nouvelle candidature.</Text>}
              renderItem={({ item }) => (
                <View style={[styles.card, { borderLeftWidth: 4, borderLeftColor: '#f59e0b' }]}>
                  <Text style={styles.memberName}>{item.member?.full_name || 'Utilisateur'}</Text>
                  <Text style={styles.memberDate}>A postulé le {new Date(item.created_at).toLocaleDateString()}</Text>
                  <View style={styles.rowActions}>
                    <TouchableOpacity style={styles.btnApprove} onPress={() => updateStatus(item.id, 'APPROVED')}><Text style={styles.btnText}>Accepter</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btnReject} onPress={() => updateStatus(item.id, 'REJECTED')}><Text style={styles.btnText}>Refuser</Text></TouchableOpacity>
                  </View>
                </View>
              )}
            />
          ) : (
            <FlatList
              data={activeMembers}
              keyExtractor={(item) => item.id}
              ListEmptyComponent={<Text style={styles.emptyText}>Aucun membre dans votre équipe.</Text>}
              renderItem={({ item }) => (
                <View style={styles.memberItem}>
                  <Text style={styles.memberName}>{item.member?.full_name || 'Utilisateur'}</Text>
                  <Text style={{ fontSize: 10, color: '#10b981', fontWeight: 'bold' }}>ACTIF</Text>
                </View>
              )}
            />
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 40, marginBottom: 10 },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  deptTitle: { fontSize: 14, color: '#f59e0b', fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  backBtn: { color: '#64748b', fontWeight: 'bold' },
  tabContainer: { flexDirection: 'row', backgroundColor: '#e2e8f0', borderRadius: 12, padding: 4, marginBottom: 20 },
  tab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10 },
  tabActive: { backgroundColor: '#fff', elevation: 2 },
  tabText: { fontSize: 13, fontWeight: '600', color: '#64748b' },
  tabTextActive: { color: '#0f172a', fontWeight: 'bold' },
  card: { backgroundColor: '#fff', padding: 15, borderRadius: 16, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  memberName: { fontWeight: 'bold', fontSize: 15, color: '#0f172a' },
  memberDate: { fontSize: 12, color: '#64748b', marginTop: 4 },
  rowActions: { flexDirection: 'row', gap: 10, marginTop: 15 },
  btnApprove: { flex: 1, backgroundColor: '#10b981', padding: 10, borderRadius: 8, alignItems: 'center' },
  btnReject: { flex: 1, backgroundColor: '#f1f5f9', padding: 10, borderRadius: 8, alignItems: 'center' },
  btnText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  emptyText: { textAlign: 'center', marginTop: 40, color: '#94a3b8' },
  memberItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', padding: 15, borderRadius: 12, marginBottom: 8, borderWidth: 1, borderColor: '#e2e8f0' }
});